package objstreamdemo;

/*
 * Mintaprogramok/14. fejezet
 * ObjStreamDemo.java
 *
 * Angster Erzs�bet: OO tervez�s �s programoz�s, Java II. k�tet
 * 2002.09.01.
 * M�dos�tva: 2015.10.22.
 * Nagy S�ra
 */

import java.io.*;

class MyClass implements Serializable {
    String szoveg=" �szt�nd�j: "; 
    int n = 67000;
  @Override
  public String toString() {
    return szoveg+Integer.toString(n);
    }
}

public class ObjStreamDemo {
  static void letrehoz() {
    try {
      ObjectOutputStream out = new ObjectOutputStream(
           new FileOutputStream("objektumok.dat"));   //1
      // Az objektumfolyamra objektumot �s primit�v adatot is �runk:
      out.writeObject(new String("Okos P�ter"));
      out.writeObject(new String("programtervez� informatikus"));
      out.writeInt(45);  // primit�v adat
      out.writeObject(new MyClass());
      out.close();
    }
    catch (FileNotFoundException ex) {
      System.out.println("Az �llom�nyt nem lehet l�trehozni!");
    }
    catch (IOException ex) {
      System.out.println("I/O hiba! "+ex);
    }
  }

  static void listaz() {
    try {
      ObjectInputStream in = new ObjectInputStream(
           new FileInputStream("objektumok.dat"));
      // A visszaolvas�s a fel�r�si sorrendben t�rt�nik:
      String s1 = (String)in.readObject();                 //2
      String s2 = (String)in.readObject();
      int i = in.readInt();    
      MyClass obj = (MyClass)in.readObject();
      in.close();
      System.out.println(s1+" "+s2+" "+i+" "+obj);
    }
    catch (FileNotFoundException ex) {
      System.out.println("Nincs ilyen �llom�ny!");
    }
    catch (ClassNotFoundException ex) {
      System.out.println("Rossz oszt�ly!");
    }
    catch (IOException ex) {
      System.out.println("I/O hiba! "+ex);
    }
  }

  public static void main(String[] args) {
    letrehoz();
    listaz();
  }
}
